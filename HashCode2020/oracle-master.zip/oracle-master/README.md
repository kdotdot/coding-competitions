# oracle
set of validators for former hashcode to help lazy/unsure students

2018q is the oracle for the 2018 qualification round
